use planets_on_wgpu::run;

fn main() {
    pollster::block_on(run());
}
